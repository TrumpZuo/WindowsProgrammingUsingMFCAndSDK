
#define IDM_FILE_NEW                  10001
#define IDM_FILE_OPEN                 10002
#define IDM_FILE_CLOSE                10003
#define IDM_FILE_SAVE                 10004
#define IDM_FILE_SAVEAS               10005
#define IDM_FILE_PRINTSETUP           10006
#define IDM_FILE_PRINT                10007
#define IDM_FILE_EXIT                 10008

#define IDM_EDIT_UNDO                 20001
#define IDM_EDIT_CUT                  20002
#define IDM_EDIT_COPY                 20003
#define IDM_EDIT_PASTE                20004
#define IDM_EDIT_CLEAR                20005
#define IDM_EDIT_SELECTALL            20006

#define IDM_WINDOW_CASCADE            30001
#define IDM_WINDOW_HTILE              30002
#define IDM_WINDOW_VTILE              30003
#define IDM_WINDOW_ICONARRANGE        30004

#define IDM_HELP_ABOUT                40001

//�����ĵ�����˽�����ݽṹ����
typedef struct tagDOCDATA
{
	TCHAR szFileName[MAX_PATH];
	TCHAR szFileTitle[MAX_PATH];
	BOOL  bNeedSave;
}DOCDATA, *PDOCDATA;
