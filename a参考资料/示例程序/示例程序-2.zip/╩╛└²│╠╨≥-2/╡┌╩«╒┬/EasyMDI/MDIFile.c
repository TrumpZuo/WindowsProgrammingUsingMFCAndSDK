/*******************************************************************
�ļ���MDIFile.c
���ܣ�MDI��ʾ�����ļ���������
********************************************************************/
#include <windows.h>
#include <commdlg.h>

static OPENFILENAME ofn;

void FileDlgInit (HWND hwnd)
{
    static TCHAR szFileFilter[] = TEXT ("Text Files (*.TXT)\0*.txt\0")  \
								  TEXT ("Text Files (*.C)\0*.c\0") \
								  TEXT ("Text Files (*.H)\0*.h\0") \
								  TEXT ("Text Files (*.RC)\0*.rc\0") \
								  TEXT ("All Files (*.*)\0*.*\0\0");
     
     ofn.lStructSize       = sizeof (OPENFILENAME);
     ofn.hwndOwner         = hwnd;
     ofn.hInstance         = NULL;
     ofn.lpstrFilter       = szFileFilter;
     ofn.lpstrCustomFilter = NULL;
     ofn.nMaxCustFilter    = 0;
     ofn.nFilterIndex      = 0;
     ofn.lpstrFile         = NULL; 
     ofn.nMaxFile          = MAX_PATH;
     ofn.lpstrFileTitle    = NULL;
     ofn.nMaxFileTitle     = MAX_PATH;
     ofn.lpstrInitialDir   = NULL;
     ofn.lpstrTitle        = NULL;
     ofn.Flags             = 0;
     ofn.nFileOffset       = 0;
     ofn.nFileExtension    = 0;
     ofn.lpstrDefExt       = TEXT ("txt");
     ofn.lCustData         = 0L;
     ofn.lpfnHook          = NULL;
     ofn.lpTemplateName    = NULL;
}

BOOL FileOpenDlg (HWND hwnd, PTSTR pstrFileName, PTSTR pstrTitleName)
{
     ofn.hwndOwner         = hwnd;
     ofn.lpstrFile         = pstrFileName;
     ofn.lpstrFileTitle    = pstrTitleName;
     ofn.Flags             = OFN_HIDEREADONLY | OFN_CREATEPROMPT;
     
     return GetOpenFileName (&ofn) ;
}

BOOL FileSaveDlg (HWND hwnd, PTSTR pstrFileName, PTSTR pstrTitleName)
{
     ofn.hwndOwner         = hwnd;
     ofn.lpstrFile         = pstrFileName;
     ofn.lpstrFileTitle    = pstrTitleName;
     ofn.Flags             = OFN_OVERWRITEPROMPT;
     
     return GetSaveFileName (&ofn);
}

BOOL FileRead (HWND hDocWnd, PTSTR pstrFileName)
{
    HWND    hEditWnd;
	DWORD   dwBytes;
    HANDLE  hFile;
    int     iFileLength;
    LPTSTR  lpBuffer;

	hEditWnd = GetWindow (hDocWnd, GW_CHILD);    //�༭�Ӵ���

	hFile = CreateFile (pstrFileName, GENERIC_READ, FILE_SHARE_READ,
                        NULL, OPEN_EXISTING, 0, NULL);

	if ((DWORD)hFile == -1)
	{
        SetWindowText (hEditWnd, TEXT ("\0")) ;
		return FALSE;
	}

	iFileLength = GetFileSize (hFile, NULL);

	lpBuffer = (LPTSTR)malloc (iFileLength+1);
	ReadFile (hFile, lpBuffer, iFileLength, &dwBytes, NULL);
	CloseHandle (hFile);
	lpBuffer[iFileLength] = '\0';
	SetWindowText (hEditWnd, lpBuffer);
	free (lpBuffer);

	return TRUE;
}

BOOL FileWrite (HWND hDocWnd, PTSTR pstrFileName)
{
    HWND    hEditWnd;
    DWORD   dwBytes;
    HANDLE  hFile;
    int     iFileLength;
    LPTSTR  lpBuffer;

	hEditWnd = GetWindow (hDocWnd, GW_CHILD);    //�༭�Ӵ���

	hFile = CreateFile (pstrFileName, GENERIC_WRITE, 0, 
                        NULL, CREATE_ALWAYS, 0, NULL);
	
	if ((DWORD)hFile == -1)
        return FALSE;

	iFileLength = GetWindowTextLength (hEditWnd);
	lpBuffer = (LPTSTR) malloc ((iFileLength + 1) * sizeof (TCHAR));

    if (!lpBuffer)  //�������ݻ�����ʧ��
	{
        CloseHandle (hFile);
		return FALSE;
	}

	GetWindowText (hEditWnd, lpBuffer, iFileLength + 1);
	WriteFile (hFile, lpBuffer, iFileLength * sizeof (TCHAR), 
				&dwBytes, NULL);
     
	CloseHandle (hFile);
	free (lpBuffer);
						
	return TRUE;
}


