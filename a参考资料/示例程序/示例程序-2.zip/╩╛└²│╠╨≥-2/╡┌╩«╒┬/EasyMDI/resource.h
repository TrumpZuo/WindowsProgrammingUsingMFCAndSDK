//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EasyMDI.rc
//
#define IDM_HELP_NNNNN                  40002
#define ID_MENUITEM40004                40004
#define ID_MENUITEM40005                40005
#define ID_MENUITEM40006                40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
