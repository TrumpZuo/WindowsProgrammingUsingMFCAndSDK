/*******************************************************************
�ļ���Graphlib.c
���ܣ���չ��ͼ������̬���ӿ�ģ��
********************************************************************/
#include <windows.h>
#include "graphlib.h"

int WINAPI CALLBACK DllMain (HINSTANCE hInstance, DWORD fdwReason,
							 LPVOID lpvReserved)
{
	return TRUE;
}

EXPORT BOOL CALLBACK DrawCBIcon (HDC hdc, RECT rect)
{
	static HPEN   hRedPen;
	HPEN          hOldPen;
	int           nPenWidth;

	//������ɫ����
	nPenWidth = max (3, max ((rect.right - rect.left) /2,
							 (rect.bottom - rect.top) /2) /8 );
	hRedPen = CreatePen (PS_SOLID, nPenWidth, RGB (255, 0, 0));

    //ѡ���»���
	hOldPen = SelectObject (hdc, hRedPen);
		
	Ellipse (hdc, rect.left, rect.top, rect.right, rect.bottom);
	RoundRect (hdc, rect.left + (rect.right - rect.left) / 6,
		       rect.top + 7 * (rect.bottom - rect.top) / 24, 
		       rect.left + 5 * (rect.right - rect.left) / 6,
			   rect.top + 17 * (rect.bottom - rect.top) / 24,
			   (rect.bottom - rect.top) / 8, (rect.bottom - rect.top) / 8);
	MoveToEx (hdc, rect.left + (rect.right - rect.left) / 2, rect.top, NULL);
	LineTo (hdc, rect.left + (rect.right - rect.left) / 2, rect.top + 7 * (rect.bottom - rect.top) / 24);
	MoveToEx (hdc, rect.left + (rect.right - rect.left) / 2, rect.top + 17 * (rect.bottom - rect.top) / 24, NULL);
	LineTo (hdc, rect.left + (rect.right - rect.left) / 2, rect.bottom);

    //ѡ���»���
	SelectObject (hdc, hOldPen);
		
	//ɾ���Խ�����
	DeleteObject (hRedPen);

	return TRUE;
}
