/*******************************************************************
����DllDemo
�ļ���DllDemo.c
���ܣ���̬���ӿ�ʾ��������չ��ͼ�����������й�����ͼ��
********************************************************************/
#include <windows.h>
#include <windowsx.h>
#include "graphlib.h"

BOOL InitWindow (HINSTANCE hInstance, int nCmdShow);
LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain (HINSTANCE hInstance,         
                    HINSTANCE hPrevInstance,     
                    PSTR szCmdLine,              
                    int iCmdShow)                
{
	MSG msg;

	if (!InitWindow (hInstance, iCmdShow))
	return FALSE;

	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage (&msg);
		DispatchMessage (&msg);
	}

	return msg.wParam;
}

static BOOL InitWindow (HINSTANCE hInstance, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT ("DllDemo");  
	HWND hwnd;   
	WNDCLASS wc;

	wc.style = CS_VREDRAW | CS_HREDRAW;
	wc.lpfnWndProc = WinProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon (hInstance, IDI_APPLICATION);
	wc.hCursor = LoadCursor (NULL, IDC_ARROW);
	wc.hbrBackground = GetStockObject (WHITE_BRUSH);
	wc.lpszMenuName = szAppName;
	wc.lpszClassName = szAppName;

	if (!RegisterClass (&wc))
	{
		MessageBox (NULL, TEXT ("ע�ᴰ����ʧ�ܣ�"), szAppName,
                    MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow (szAppName, TEXT ("��̬���ӿ�ʾ�����򡪳���ģ��"), 
                     	WS_OVERLAPPEDWINDOW,    
                        CW_USEDEFAULT, CW_USEDEFAULT,  
                        CW_USEDEFAULT, CW_USEDEFAULT,  
                        NULL, NULL, hInstance, NULL);

	if( !hwnd ) return FALSE;

	ShowWindow( hwnd, iCmdShow );
	UpdateWindow( hwnd );
	return TRUE;
}

LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HDC           hdc;
	PAINTSTRUCT   ps;
	RECT          rect;
    static int    nPixelWidth, nPixelHeight, cxClient, cyClient,
		          cxBox, cyBox;
	int           nScale;

	switch (message)
	{
	case WM_CREATE:
		//��ȡ�豸���ص�Ŀ��Ⱥ͸߶�
		hdc = GetDC (hWnd);
		nPixelWidth = GetDeviceCaps (hdc, ASPECTX);			
		nPixelHeight = GetDeviceCaps (hdc, ASPECTY);
		ReleaseDC (hWnd, hdc);
			
		return 0;

	case WM_SIZE:
		cxClient = LOWORD (lParam);
		cyClient = HIWORD (lParam);
		
		//��������ͼ�����Ӿ��ο��ȼ��߶�
		nScale = min (cxClient * nPixelWidth, cyClient * nPixelHeight) / 2;
		cxBox = nScale / nPixelWidth;
		cyBox = nScale / nPixelHeight;
			
		return 0;

	case WM_PAINT:
		hdc=BeginPaint (hWnd, &ps);
		GetClientRect (hWnd, &rect);

		//��������ͼ�����Ӿ������Ͻǡ����½�����
		rect.left = (rect.right - cxBox) / 2;
		rect.top = (rect.bottom - cyBox) / 2;
		rect.right = rect.left + cxBox;
		rect.bottom = rect.top + cyBox;

		//���ö�̬���ӿ��к���������ͼ��
		DrawCBIcon (hdc, rect);
		
		EndPaint ( hWnd, &ps ); 
		return 0;

	case WM_DESTROY:      
		PostQuitMessage (0); 
		return 0;
	}

	return DefWindowProc (hWnd, message, wParam, lParam);

}

