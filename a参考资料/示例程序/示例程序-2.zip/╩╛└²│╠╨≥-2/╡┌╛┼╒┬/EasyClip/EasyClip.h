#define IDM_TEXT                      10001
#define IDM_BITMAP                    10002

#define IDM_EDIT_CUT                  20001
#define IDM_EDIT_PASTE                20002

#define IDM_HELP_ABOUT                30001
