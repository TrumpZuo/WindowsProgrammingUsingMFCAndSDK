/*******************************************************************
����EasyEdit
�ļ���EasyEdit.c
���ܣ���׼�ؼ���ʾ�����ı��༭��
********************************************************************/
#include <windows.h>
#include <windowsx.h>

BOOL InitWindow (HINSTANCE hInstance, int nCmdShow);
LRESULT CALLBACK MainWndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow)
{
	MSG msg;

	if (!InitWindow (hInstance, iCmdShow))
	return FALSE;

	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage (&msg);
		DispatchMessage (&msg);
	}

	return msg.wParam;
}

static BOOL InitWindow (HINSTANCE hInstance, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT ("EasyEdit");
	HWND hwnd;   
	WNDCLASS wc; 

	wc.style = CS_VREDRAW | CS_HREDRAW;
	wc.lpfnWndProc = MainWndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon (hInstance, IDI_APPLICATION);
	wc.hCursor = LoadCursor (NULL, IDC_ARROW);
	wc.hbrBackground = GetStockObject (WHITE_BRUSH);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = szAppName;

	if (!RegisterClass (&wc))
	{
		MessageBox (NULL, TEXT ("ע�ᴰ����ʧ�ܣ�"), szAppName,
                    MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow (szAppName, 
	                    TEXT ("��׼�ؼ���ʾ�����ı��༭��"),
                     	WS_OVERLAPPEDWINDOW,
                        CW_USEDEFAULT, 
                        CW_USEDEFAULT, 
                        CW_USEDEFAULT,
                        CW_USEDEFAULT,
                        NULL, 
                        NULL,
                        hInstance, 
                        NULL); 

	if( !hwnd ) return FALSE;

	ShowWindow ( hwnd, iCmdShow );
	UpdateWindow ( hwnd );
	return TRUE;
}

LRESULT CALLBACK MainWndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static HWND  hWndEdit;

	switch (message)
	{
	case WM_CREATE:
		hWndEdit=CreateWindow (TEXT ("edit"),			        //��������
							  NULL,			                    //�ޱ���
							  WS_CHILD|WS_VISIBLE|WS_HSCROLL|	//�༭�ؼ����
							  WS_VSCROLL|WS_BORDER|ES_LEFT|
							  ES_MULTILINE|ES_AUTOHSCROLL|
							  ES_AUTOVSCROLL,
							  0,0,0,0,	
							  hWnd,		                        //�����ھ��
							  (HMENU)1,		                        //�༭�ؼ��Ӵ��ڱ�ʶ
							  (HINSTANCE) GetWindowLong (hWnd, GWL_HINSTANCE),
							  NULL);
		return 0;

	case WM_SETFOCUS:
		SetFocus (hWndEdit);
		return 0;

	case WM_SIZE:
		MoveWindow (hWndEdit, 0, 0, LOWORD(lParam), HIWORD(lParam), TRUE);
		return 0;

	case WM_COMMAND:        	// ��Ӧ�༭�ؼ�֪ͨ��Ϣ
		if (lParam)
		{
			WORD w, W1, W2, W3;
			w = LOWORD (wParam);
			W1 = HIWORD(wParam);
			W2 = LOWORD (lParam);
			W3 = HIWORD(lParam);
			//�༭�ؼ�֪ͨ��Ϣ
			if ((LOWORD (wParam) == 1) &&
				(HIWORD(wParam) == EN_ERRSPACE || HIWORD (wParam) == EN_MAXTEXT))
				MessageBox (hWnd,TEXT ("�༭�ؼ��ڴ����"), 
							TEXT ("�˵�ʾ������"), MB_OK|MB_ICONSTOP);	
		}
		return 0;

	case WM_DESTROY: 
		PostQuitMessage (0);
		return 0;
	}

	return DefWindowProc (hWnd, message, wParam, lParam);

} //���� MainWndProc ����

