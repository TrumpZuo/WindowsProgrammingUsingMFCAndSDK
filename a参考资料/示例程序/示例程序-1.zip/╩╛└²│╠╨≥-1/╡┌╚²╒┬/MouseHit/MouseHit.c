/*******************************************************************
����MouseHit
�ļ���MouseHit.c
���ܣ�������в�����ʾ����
********************************************************************/
#include <windows.h>
#include <windowsx.h>
#include "resource.h"

#define ROW_NUM 4    //����
#define COL_NUM 5    //����

BOOL InitWindow (HINSTANCE hInstance, int nCmdShow);
LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow)
{
	MSG msg;

	if (!InitWindow (hInstance, iCmdShow))
		return FALSE;

	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage (&msg);
		DispatchMessage (&msg);
	}

	return msg.wParam;
}

static BOOL InitWindow (HINSTANCE hInstance, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT ("MouseHit");
	HWND hwnd;   
	WNDCLASS wc; 

	wc.style         = CS_VREDRAW | CS_HREDRAW | CS_DBLCLKS;
	wc.lpfnWndProc   = WinProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon (hInstance, IDI_APPLICATION);
	wc.hCursor       = LoadCursor (hInstance, MAKEINTRESOURCE(IDC_CURSOR1)); 
					 //LoadCursor (NULL, IDC_ARROW);
	wc.hbrBackground = GetStockObject (WHITE_BRUSH);
	wc.lpszMenuName  = NULL;
	wc.lpszClassName = szAppName;

	if (!RegisterClass (&wc))
	{
		MessageBox (NULL, TEXT ("ע�ᴰ����ʧ�ܣ�"), szAppName,
                    MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow (szAppName, 
	                    TEXT ("������в�����ʾ����"),
                     	WS_OVERLAPPEDWINDOW,
                        CW_USEDEFAULT, CW_USEDEFAULT, 
						CW_USEDEFAULT, CW_USEDEFAULT,
                        NULL, NULL, hInstance, NULL); 

	if( !hwnd ) return FALSE;

	ShowWindow( hwnd, iCmdShow );
	UpdateWindow( hwnd );
	return TRUE;
}

LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    static BOOL bInvert[COL_NUM][ROW_NUM];
    static BOOL bChecked[COL_NUM][ROW_NUM];
    static int  nXBox, nYBox ;
    HDC         hdc;
    int         x, y;
    PAINTSTRUCT ps;
    RECT        rect;
    
    switch (message)
    {
    case WM_SIZE:
        nXBox = LOWORD (lParam) / COL_NUM;
        nYBox = HIWORD (lParam) / ROW_NUM;
        return 0;
          
    case WM_LBUTTONDOWN:
		x = LOWORD (lParam) / nXBox;
        y = HIWORD (lParam) / nYBox;
          
        if (x < COL_NUM && y < ROW_NUM)
        {
			bInvert [x][y] ^=1;
            rect.left   = x * nXBox;
            rect.top    = y * nYBox;
            rect.right  = (x+1) * nXBox;
            rect.bottom = (y+1) * nYBox;
               
	        hdc = GetDC (hWnd);
            InvertRect (hdc, &rect);
	        ReleaseDC (hWnd, hdc);
        }
		return 0;
          
    case WM_LBUTTONDBLCLK:
    case WM_RBUTTONDOWN:
		x = LOWORD (lParam) / nXBox;
        y = HIWORD (lParam) / nYBox;
          
        if (x < COL_NUM && y < ROW_NUM)
        {
            if (message == WM_LBUTTONDBLCLK) bChecked[x][y] =1;
			else bChecked[x][y] =0;

			rect.left   = x * nXBox;
            rect.top    = y * nYBox;
            rect.right  = (x+1) * nXBox;
            rect.bottom = (y+1) * nYBox;
               
            InvalidateRect (hWnd, &rect, FALSE);
        }
		return 0;

    case WM_PAINT:
        hdc = BeginPaint (hWnd, &ps);
          
        for (x = 0 ; x < COL_NUM ; x++)
        for (y = 0 ; y < ROW_NUM ; y++)
		{
            Rectangle (hdc, x * nXBox, y * nYBox,
                      (x+1) * nXBox, (y+1) * nYBox);

			if (bInvert [x][y])
			{
				rect.left   = x * nXBox;
				rect.top    = y * nYBox;
			    rect.right  = (x + 1) * nXBox;
		        rect.bottom = (y + 1) * nYBox;
	            InvertRect (hdc, &rect);
			}

			if (bChecked [x][y])
			{
				HPEN hPen = CreatePen (PS_SOLID, 2, RGB(255, 0, 0));
				SelectObject(hdc, hPen);
                MoveToEx (hdc,  x * nXBox, y * nYBox, NULL);
                LineTo (hdc, (x+1) * nXBox, (y+1) * nYBox);
                MoveToEx (hdc, x * nXBox, (y+1) * nYBox, NULL);
                LineTo (hdc, (x+1) * nXBox, y * nYBox);
				SelectObject (hdc, GetStockObject (BLACK_PEN));

				DeleteObject (hPen);
			}
		}
		EndPaint (hWnd, &ps);
        return 0;
               
	case WM_DESTROY: 
		PostQuitMessage (0);
		return 0;
	}

	return DefWindowProc (hWnd, message, wParam, lParam);

} //���� WinProc ����

