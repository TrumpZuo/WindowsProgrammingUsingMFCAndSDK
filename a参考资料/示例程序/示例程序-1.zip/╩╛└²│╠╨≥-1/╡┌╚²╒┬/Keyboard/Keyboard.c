/*******************************************************************
����Keyboard
�ļ���Keyboard.c
���ܣ�����������ʾ����
********************************************************************/
#include <windows.h>
#include <windowsx.h>

BOOL InitWindow (HINSTANCE hInstance, int nCmdShow);
LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain (HINSTANCE hInstance, 
                    HINSTANCE hPrevInstance,
                    PSTR szCmdLine,
                    int iCmdShow)
{
	MSG msg;

	if (!InitWindow (hInstance, iCmdShow))
	return FALSE;

	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage (&msg);         //ת�����̻�����Ϣ���Ի���ַ���Ϣ
		DispatchMessage (&msg);
	}

	return msg.wParam;
}

static BOOL InitWindow (HINSTANCE hInstance, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT ("Keyboard");
	HWND hwnd;
	WNDCLASS wc;

	wc.style = CS_VREDRAW | CS_HREDRAW;
	wc.lpfnWndProc = WinProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon (hInstance, IDI_APPLICATION);
	wc.hCursor = LoadCursor (NULL, IDC_ARROW);
	wc.hbrBackground = GetStockObject (WHITE_BRUSH);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = szAppName;

	if (!RegisterClass (&wc))
	{
		MessageBox (NULL, TEXT ("ע�ᴰ����ʧ�ܣ�"), szAppName,
                    MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow (szAppName,
	                    TEXT ("����������ʾ����"),
                     	WS_OVERLAPPEDWINDOW,
                        CW_USEDEFAULT,
                        CW_USEDEFAULT,
                        CW_USEDEFAULT,
                        CW_USEDEFAULT,
                        NULL,
                        NULL,
                        hInstance,
                        NULL);

	if( !hwnd ) return FALSE;

	ShowWindow( hwnd, iCmdShow );
	UpdateWindow( hwnd );
	return TRUE;
}

//���ں���
LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HDC           hdc;
	RECT          rect;
	char          aChar;             //�ַ���
	int i,j;

	switch (message)
	{
	case WM_SETFOCUS:
		CreateCaret (hWnd, NULL, 2, 15);	//����8*15��С�Ĳ����
		SetCaretPos (10, 10);               //���ò������λ��Ϊ�ͻ������Ͻ�
		ShowCaret (hWnd);                   //��ʾ�����
		return 0;
	case WM_KILLFOCUS:
		HideCaret (hWnd);                    //���ز����
		DestroyCaret ();                     //���������
		return 0;
//	case WM_SYSKEYDOWN:
//		MessageBeep(MB_ICONHAND);
//		return 0;
	case WM_KEYDOWN:
		if ( LOWORD(lParam) > 1 )
		{
			i=lParam&0xffff;
			MessageBeep(0);
		}
//		MessageBeep(MB_ICONASTERISK);
		return 0;

	case WM_CHAR:
		if ((lParam&0xffff) > 1 && (lParam&0xffff)<255)
		{
			i=lParam&0xffff;
			MessageBeep(0);
		}
		aChar = wParam;
		//for (j=0; j<1000000;j++)
		Sleep(2000);
						

		hdc = GetDC (hWnd);
		GetClientRect (hWnd, &rect);

//		DrawText (hdc, TEXT ("    "), -1, &rect, 
//					DT_SINGLELINE | DT_CENTER | DT_VCENTER); //�����һ���ַ�
		DrawText (hdc, &aChar, 1, &rect, 
					DT_SINGLELINE | DT_CENTER | DT_VCENTER); //��ʾ��ǰ�ַ�

		HideCaret (hWnd);
		SetCaretPos (rect.right/2+3, rect.bottom/2-7);
		ShowCaret (hWnd);
		
		ReleaseDC (hWnd, hdc);

		return 0;

	case WM_DESTROY:
			
		PostQuitMessage (0);
		return 0;
	}			  


	return DefWindowProc (hWnd, message, wParam, lParam);

} //���� WinProc ����

