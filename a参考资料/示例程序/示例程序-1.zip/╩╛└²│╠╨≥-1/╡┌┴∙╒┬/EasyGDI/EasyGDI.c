/*******************************************************************
����EasyGDI
�ļ���EasyGDI.c
���ܣ�������ͼ���������ʡ���ˢ��Ӧ��
********************************************************************/
#include <windows.h>
#include <windowsx.h>
#include "easygdi.h"

BOOL InitWindow (HINSTANCE hInstance, int nCmdShow);
LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain (HINSTANCE hInstance,         
                    HINSTANCE hPrevInstance,     
                    PSTR szCmdLine,              
                    int iCmdShow)                
{
	MSG msg;

	if (!InitWindow (hInstance, iCmdShow))
	return FALSE;

	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage (&msg);
		DispatchMessage (&msg);
	}

	return msg.wParam;
}

static BOOL InitWindow (HINSTANCE hInstance, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT ("EasyGDI");  
	HWND hwnd;   
	WNDCLASS wc;

	wc.style = CS_VREDRAW | CS_HREDRAW;
	wc.lpfnWndProc = WinProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon (hInstance, IDI_APPLICATION);
	wc.hCursor = LoadCursor (NULL, IDC_ARROW);
	wc.hbrBackground = GetStockObject (WHITE_BRUSH);
	wc.lpszMenuName = szAppName;
	wc.lpszClassName = szAppName;

	if (!RegisterClass (&wc))
	{
		MessageBox (NULL, TEXT ("ע�ᴰ����ʧ�ܣ�"), szAppName,
                    MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow (szAppName, TEXT ("����GDI����"), 
                     	WS_OVERLAPPEDWINDOW,    
                        CW_USEDEFAULT, CW_USEDEFAULT,  
                        CW_USEDEFAULT, CW_USEDEFAULT,  
                        NULL, NULL, hInstance, NULL);

	if( !hwnd ) return FALSE;

	ShowWindow( hwnd, iCmdShow );
	UpdateWindow( hwnd );
	return TRUE;
}

LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HDC           hdc;
	PAINTSTRUCT   ps;
	RECT          rect;
	LOGPEN        logpen;
	HMENU         hMenu;
	static HMENU  hPopMenu;
    static int    iSelectionFunc = IDM_FUNC_LINETO ;
    static int    iSelectionPen = IDM_PEN_BLACK ;
    static int    iSelectionBrush = IDM_BRUSH_WHITE ;
	static HPEN   hRedDashdotPen, hBlueSolidPen;
	HPEN          hOldPen;
	HBRUSH        hNewBrush, hOldBrush;
	POINT         ptDiamond[5], pt;

	switch (message)
	{
	case WM_CREATE:
		//������ɫ�㻮�߻���
		hRedDashdotPen = CreatePen (PS_DASHDOT, 1, RGB (255, 0, 0));			
			
		//��������Ϊ3����ɫ����
		logpen.lopnStyle = PS_SOLID;
		logpen.lopnWidth.x = 3;
		logpen.lopnColor = RGB (0, 0, 255); 
		hBlueSolidPen = CreatePenIndirect (&logpen);
			
		//��ȡ��ݲ˵����
		hPopMenu = LoadMenu (((LPCREATESTRUCT)lParam)->hInstance,
					         TEXT ("PopMenu"));
		//�ٻ�ȡ hPopMenu ��ʶ�Ŀ�ݲ˵���Ψһ�Ĳ˵������
		hPopMenu = GetSubMenu (hPopMenu, 0);
		
		return 0;

	case WM_COMMAND:
        hMenu = GetMenu (hWnd) ;
          
        switch (LOWORD (wParam))
        {
        case IDM_FILE_EXIT:
            SendMessage (hWnd, WM_CLOSE, 0, 0) ;
            return 0 ;
               
        case IDM_FUNC_LINETO:
        case IDM_FUNC_POLYLINE:
        case IDM_FUNC_ARC:
        case IDM_FUNC_RECTANGLE:
        case IDM_FUNC_ELLIPSE:
        case IDM_FUNC_ROUNDRECT:
        case IDM_FUNC_CHORD:
        case IDM_FUNC_PIE:
        case IDM_FUNC_POLYGON:
            CheckMenuItem (hMenu, iSelectionFunc, MF_UNCHECKED) ;
            iSelectionFunc = LOWORD (wParam) ;
            CheckMenuItem (hMenu, iSelectionFunc, MF_CHECKED) ;
               
            InvalidateRect (hWnd, NULL, TRUE) ;
            return 0 ;
               
        case IDM_PEN_BLACK:
        case IDM_PEN_REDDASHDOT:
        case IDM_PEN_BLUESOLID: 
              
            CheckMenuItem (hMenu, iSelectionPen, MF_UNCHECKED) ;
            iSelectionPen = LOWORD (wParam) ;
            CheckMenuItem (hMenu, iSelectionPen, MF_CHECKED) ;
               
            InvalidateRect (hWnd, NULL, TRUE) ;
            return 0 ;
               
        case IDM_BRUSH_WHITE:
        case IDM_BRUSH_LTGRAY:
        case IDM_BRUSH_COLORSOLID: 
        case IDM_BRUSH_CROSS:
             
            CheckMenuItem (hMenu, iSelectionBrush, MF_UNCHECKED) ;
            iSelectionBrush = LOWORD (wParam) ;
            CheckMenuItem (hMenu, iSelectionBrush , MF_CHECKED) ;
               
            InvalidateRect (hWnd, NULL, TRUE) ;
            return 0 ;

		case IDM_ABOUT:
            MessageBox (hWnd, TEXT ("����GDI���򣺻�����ͼ�����Լ����ʡ���ˢ�����ʹ��"),
                        TEXT ("����GDI����"), MB_OK | MB_ICONINFORMATION) ;
            return 0 ;
        }
		

	case WM_RBUTTONUP:
		pt.x = LOWORD (lParam);
		pt.y = HIWORD (lParam);
		ClientToScreen (hWnd, &pt);
		TrackPopupMenu (hPopMenu,                            //��ݲ˵����
			TPM_LEFTALIGN | TPM_TOPALIGN | TPM_LEFTBUTTON, //��־ѡ��
			pt.x, pt.y, 0, hWnd, NULL);
		return 0;

	case WM_PAINT:
		hdc=BeginPaint (hWnd, &ps);
		GetClientRect (hWnd, &rect);

        //ѡ���»���
		switch (iSelectionPen)
		{
		case IDM_PEN_BLACK:
			hOldPen = SelectObject (hdc, GetStockObject(BLACK_PEN));
			break;
		case IDM_PEN_REDDASHDOT:
			hOldPen = SelectObject (hdc, hRedDashdotPen);
			break;
		case IDM_PEN_BLUESOLID:
			hOldPen = SelectObject (hdc, hBlueSolidPen);
			break;
		}

        //ѡ���»�ˢ
		switch (iSelectionBrush)
		{
		case IDM_BRUSH_WHITE:
			hOldBrush = SelectObject (hdc, GetStockObject(WHITE_BRUSH));
			break;
		case IDM_BRUSH_LTGRAY:
			hOldBrush = SelectObject (hdc, GetStockObject(LTGRAY_BRUSH));
			break;
		case IDM_BRUSH_COLORSOLID:
			//������ѡ���ɫʵ�廭ˢ
			hNewBrush = CreateSolidBrush (RGB (0, 255, 255));
			hOldBrush = SelectObject (hdc, hNewBrush);
			break;
		case IDM_BRUSH_CROSS:
			//������ѡ����ɫʮ��Ӱ�߻�ˢ
			hNewBrush = CreateHatchBrush (HS_CROSS, RGB (0, 255, 0));
			hOldBrush = SelectObject (hdc, hNewBrush);
			break;
		}

        //������Ӧ��GDI��ͼ����������ʾͼ��
		switch (iSelectionFunc)
		{
		case IDM_FUNC_LINETO:
			MoveToEx (hdc, 0, rect.bottom / 2, NULL);
			LineTo (hdc, rect.right, rect.bottom / 2);
			MoveToEx (hdc, rect.right / 2, 0, NULL);
			LineTo (hdc, rect.right / 2, rect.bottom);
			break;

		case IDM_FUNC_POLYLINE:
			ptDiamond[0].x = 0;
			ptDiamond[0].y = rect.bottom / 2;

			ptDiamond[1].x = rect.right / 2;
			ptDiamond[1].y = 0;

			ptDiamond[2].x = rect.right;
			ptDiamond[2].y = rect.bottom / 2;

			ptDiamond[3].x = rect.right / 2;
			ptDiamond[3].y = rect.bottom;

			ptDiamond[4].x = 0;
			ptDiamond[4].y = rect.bottom / 2;

			Polyline (hdc, ptDiamond, 5);
			break;

		case IDM_FUNC_ARC:
			Arc (hdc, rect.left, rect.top, rect.right, rect.bottom,
				 rect.right, 3 * rect.bottom / 4,
				 rect.left, rect.bottom / 4);
			break;

		case IDM_FUNC_RECTANGLE:
			Rectangle (hdc, rect.right / 4, rect.bottom / 4, 
				       3 * rect.right / 4, 3 * rect.bottom / 4);
			break;

		case IDM_FUNC_ELLIPSE:
			Ellipse (hdc, rect.right / 4, rect.bottom / 4, 
				       3 * rect.right / 4, 3 * rect.bottom / 4);
			break;

		case IDM_FUNC_ROUNDRECT:
			RoundRect (hdc, rect.right / 4, rect.bottom / 4, 
				       3 * rect.right / 4, 3 * rect.bottom / 4,
					   rect.right / 4, rect.bottom / 4);
			break;

		case IDM_FUNC_CHORD:
			Chord (hdc, rect.left, rect.top, rect.right, rect.bottom,
				rect.right, 3 * rect.bottom / 4,
				rect.right / 2, rect.top);
			break;

		case IDM_FUNC_PIE:
			Pie (hdc, rect.left, rect.top, rect.right, rect.bottom,
				rect.right, 3 * rect.bottom / 4,
				rect.right / 2, rect.top);
			break;

		case IDM_FUNC_POLYGON:
			if (GetPolyFillMode(hdc)==WINDING)
				SetPolyFillMode(hdc, ALTERNATE);
			else
				SetPolyFillMode(hdc, WINDING);

			ptDiamond[0].x = 0;
			ptDiamond[0].y = rect.bottom / 3;

			ptDiamond[1].x = rect.right;
			ptDiamond[1].y = rect.bottom / 3;

			ptDiamond[2].x = rect.right / 4;
			ptDiamond[2].y = rect.bottom;

			ptDiamond[3].x = rect.right / 2;
			ptDiamond[3].y = 0;

			ptDiamond[4].x = 3 * rect.right / 4;
			ptDiamond[4].y = rect.bottom;

			Polygon (hdc, ptDiamond, 5);
			break;

		}

		//���ʡ���ˢ��ԭ
		SelectObject (hdc, hOldPen);
		SelectObject (hdc, hOldBrush);

		//ɾ���Խ���ˢ
		DeleteObject (hNewBrush);

		EndPaint ( hWnd, &ps ); 
		return 0;

	case WM_DESTROY:      
		//ɾ���Խ�����
		DeleteObject (hRedDashdotPen);
		DeleteObject (hBlueSolidPen);

		PostQuitMessage (0); 
		return 0;
	}

	return DefWindowProc (hWnd, message, wParam, lParam);

}

