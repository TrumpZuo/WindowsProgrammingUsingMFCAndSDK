#define IDM_FILE_EXIT                 1001

// λͼ�˵���
#define IDM_NEWBITMAP                 2001
#define IDM_LOADBITMAP                2002
#define IDM_SNATCHSCREEN              2003

// ��ʾ��ʽ�˵���
#define IDM_BITBLT                    3001
#define IDM_STRETCH                   3002 
#define IDM_COMPRESS                  3003 
#define IDM_PATTERNBRUSH              3004

// ��դ�����˵���
#define IDM_SRCCOPY         	      4001
#define IDM_NOTSRCCOPY                4002

#define IDM_ABOUT 	        	      5001
