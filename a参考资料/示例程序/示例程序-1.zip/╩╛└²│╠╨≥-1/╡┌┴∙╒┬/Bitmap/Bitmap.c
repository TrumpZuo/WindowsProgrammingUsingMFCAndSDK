/*******************************************************************
����Bitmap
�ļ���Bitmap.c
���ܣ�λͼ��ʾ����
********************************************************************/
#include <windows.h>
#include <windowsx.h>
#include "bitmap.h"

BOOL InitWindow (HINSTANCE hInstance, int nCmdShow);
LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain (HINSTANCE hInstance,         
                    HINSTANCE hPrevInstance,     
                    PSTR szCmdLine,              
                    int iCmdShow)                
{
	MSG msg;

	if (!InitWindow (hInstance, iCmdShow))
	return FALSE;

	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage (&msg);
		DispatchMessage (&msg);
	}

	return msg.wParam;
}

static BOOL InitWindow (HINSTANCE hInstance, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT ("Bitmap");  
	HWND hwnd;   
	WNDCLASS wc;

	wc.style = CS_VREDRAW | CS_HREDRAW;
	wc.lpfnWndProc = WinProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon (hInstance, IDI_APPLICATION);
	wc.hCursor = LoadCursor (NULL, IDC_ARROW);
	wc.hbrBackground = GetStockObject (WHITE_BRUSH);
	wc.lpszMenuName = szAppName;
	wc.lpszClassName = szAppName;

	if (!RegisterClass (&wc))
	{
		MessageBox (NULL, TEXT ("ע�ᴰ����ʧ�ܣ�"), szAppName,
                    MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow (szAppName, TEXT ("λͼ��ʾ����"), 
                     	WS_OVERLAPPEDWINDOW,    
                        CW_USEDEFAULT, CW_USEDEFAULT,  
                        CW_USEDEFAULT, CW_USEDEFAULT,  
                        NULL, NULL, hInstance, NULL);

	if( !hwnd ) return FALSE;

	ShowWindow( hwnd, iCmdShow );
	UpdateWindow( hwnd );
	return TRUE;
}

LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HDC             hdc, hdcWnd;
	PAINTSTRUCT     ps;
	RECT            rect;
	HMENU           hMenu;
	static TCHAR    szText[] = TEXT ("λͼ");
    static int      iSelectedBitmap = IDM_NEWBITMAP;
    static int      iShowMode = IDM_BITBLT;
    static DWORD    iROP = IDM_SRCCOPY;
	static HDC      hdcMem;
	static HBITMAP  hBitmap;
	SIZE            size;
	HBITMAP         hOldBitmap;
	BITMAP          bm;
	int             nWidthSrc, nHeightSrc;
	int             nWidthDest, nHeightDest;
	HBRUSH          hPatternBrush, hOldBrush;

	switch (message)
	{
	case WM_CREATE:         //�����ڴ��豸������
		hdc = GetDC (hWnd);
		hdcMem = CreateCompatibleDC (hdc);			
		ReleaseDC (hWnd, hdc);
		return 0;

    case WM_INITMENUPOPUP:
        if (lParam == 3){      // ��դ������˵����
            if (iShowMode == IDM_BITBLT){
				EnableMenuItem ((HMENU) wParam, IDM_SRCCOPY, MF_ENABLED);
				EnableMenuItem ((HMENU) wParam, IDM_NOTSRCCOPY, MF_ENABLED);}
            else{
				EnableMenuItem ((HMENU) wParam, IDM_SRCCOPY, MF_GRAYED);
				EnableMenuItem ((HMENU) wParam, IDM_NOTSRCCOPY, MF_GRAYED);}
        }
        return 0 ;
 
	case WM_COMMAND:        //��Ӧ�˵�����
        hMenu = GetMenu (hWnd) ;
          
        switch (LOWORD (wParam))
        {
        case IDM_FILE_EXIT:
            SendMessage (hWnd, WM_CLOSE, 0, 0) ;
            return 0 ;
               
        case IDM_NEWBITMAP:
        case IDM_LOADBITMAP:
        case IDM_SNATCHSCREEN:
            CheckMenuItem (hMenu, iSelectedBitmap, MF_UNCHECKED) ;
            iSelectedBitmap = LOWORD (wParam) ;
            CheckMenuItem (hMenu, iSelectedBitmap, MF_CHECKED) ;

			InvalidateRect (hWnd, NULL, TRUE) ;
            return 0 ;
               
        case IDM_BITBLT:
        case IDM_STRETCH:
        case IDM_COMPRESS:
        case IDM_PATTERNBRUSH: 
            CheckMenuItem (hMenu, iShowMode, MF_UNCHECKED) ;
            iShowMode = LOWORD (wParam) ;
            CheckMenuItem (hMenu, iShowMode, MF_CHECKED) ;
               
            InvalidateRect (hWnd, NULL, TRUE) ;
            return 0 ;
               
        case IDM_SRCCOPY:
        case IDM_NOTSRCCOPY:
            CheckMenuItem (hMenu, iROP, MF_UNCHECKED) ;
            iROP = LOWORD (wParam) ;
            CheckMenuItem (hMenu, iROP , MF_CHECKED) ;
               
            InvalidateRect (hWnd, NULL, TRUE) ;
            return 0 ;

		case IDM_ABOUT:
            MessageBox (hWnd, TEXT ("λͼ��ʾ������ʾλͼ��������ʾ����դ����"),
                        TEXT ("λͼ��ʾ����"), MB_OK | MB_ICONINFORMATION) ;
            return 0 ;
        }
		
	case WM_PAINT:                             //�����ػ���Ϣ
		hdc=BeginPaint (hWnd, &ps);            
		
		GetClientRect (hWnd, &rect);

		switch (iSelectedBitmap)               //���������λͼ����ȡλͼ���         
		{
	    case IDM_NEWBITMAP:
			GetTextExtentPoint32 (hdc, szText, lstrlen (szText), &size);
			nWidthSrc = 2 * size.cx;
			nHeightSrc = 2 * size.cy;

			//������λͼ����ѡ���ڴ��豸������������������λͼ��
			hBitmap = CreateCompatibleBitmap (hdc, nWidthSrc, nHeightSrc);			
			hOldBitmap = SelectObject (hdcMem, hBitmap);
		
			PatBlt (hdcMem, 0, 0, nWidthSrc, nHeightSrc, WHITENESS);    //�ð�ɫ�����λͼ
			Rectangle (hdcMem, 0, 0, nWidthSrc, nHeightSrc);
			TextOut (hdcMem, size.cx / 2, size.cy / 2, szText, lstrlen (szText));
		
			SelectObject (hdcMem, hOldBitmap);
			break;

	    case IDM_LOADBITMAP:
			//������Ϊ MYBITMAP ����֪λͼ
			hBitmap = LoadBitmap ((HINSTANCE)GetWindowLong (hWnd, GWL_HINSTANCE), TEXT ("MYBITMAP"));
			GetObject (hBitmap, sizeof (BITMAP), &bm);
			nWidthSrc = bm.bmWidth;
			nHeightSrc = bm.bmHeight;
			break;

		case IDM_SNATCHSCREEN:
			//ȡӦ�ó��򴰿����Ͻ�ͼ��ͼ����λͼ
			nWidthSrc = GetSystemMetrics (SM_CXFRAME) + GetSystemMetrics (SM_CXSIZE);
			nHeightSrc = GetSystemMetrics (SM_CYFRAME) + GetSystemMetrics (SM_CYSIZE);
			hdcWnd = GetWindowDC (hWnd);
			
			//����һ���հ���λͼ��ѡ���ڴ��豸������
			hBitmap = CreateCompatibleBitmap (hdc, nWidthSrc, nHeightSrc);			
			hOldBitmap = SelectObject (hdcMem, hBitmap);

			//���������Ͻ�Ӧ�ó���ͼ��ͼ�����䵽�ڴ�λͼ��
			BitBlt (hdcMem, 0, 0, nWidthSrc, nHeightSrc, hdcWnd, 0, 0, SRCCOPY);

			SelectObject (hdcMem, hOldBitmap);
			ReleaseDC (hWnd, hdcWnd);

			break;
		}

		switch (iShowMode)                     //��ʾλͼ
		{
		case IDM_BITBLT:
			hOldBitmap = SelectObject (hdcMem, hBitmap);
			
		if (iROP == IDM_NOTSRCCOPY) 
			BitBlt (hdc, (rect.right - nWidthSrc)/2, (rect.bottom - nHeightSrc)/2,
						nWidthSrc, nHeightSrc, hdcMem, 0, 0, BLACKNESS);
		if (iROP == IDM_SRCCOPY) 
			BitBlt (hdc, (rect.right - nWidthSrc)/2, (rect.bottom - nHeightSrc)/2,
					nWidthSrc, nHeightSrc, hdcMem, 0, 0, SRCCOPY);
			
			SelectObject (hdcMem, hOldBitmap);
			break;

		case IDM_STRETCH:
			nWidthDest = rect.right;
			nHeightDest = rect.bottom;

			hOldBitmap = SelectObject (hdcMem, hBitmap);
			StretchBlt (hdc, 0, 0, nWidthDest, nHeightDest,
						hdcMem, 0, 0, nWidthSrc, nHeightSrc, SRCCOPY);
			SelectObject (hdcMem, hOldBitmap);
			break;

        case IDM_COMPRESS:
			nWidthDest = -nWidthSrc/2;
			nHeightDest = -nHeightSrc/2;

			hOldBitmap = SelectObject (hdcMem, hBitmap);
			StretchBlt (hdc, rect.right/2 + nWidthSrc/4 , rect.bottom/2 + nHeightSrc/4 ,
				        nWidthDest, nHeightDest, hdcMem, 0, 0, nWidthSrc, nHeightSrc, SRCCOPY);
			SelectObject (hdcMem, hOldBitmap);
			break;

		case IDM_PATTERNBRUSH:
			hPatternBrush = CreatePatternBrush (hBitmap);
			hOldBrush = SelectObject (hdc, hPatternBrush);
			Rectangle (hdc, 0, 0, rect.right, rect.bottom);
			SelectObject (hdc, hOldBrush);
			break;
		}
		
		if (hPatternBrush) DeleteObject (hPatternBrush);   //ɾ��ͼ����ˢ
		if (hBitmap)  DeleteObject (hBitmap);              //ɾ��λͼ

		EndPaint (hWnd, &ps); 
		return 0;

	case WM_DESTROY:      
		DeleteDC (hdcMem);
		 
		PostQuitMessage (0); 
		return 0;
	}

	return DefWindowProc (hWnd, message, wParam, lParam);

}

