/*******************************************************************
����EasyDraw
�ļ���EasyDraw.c
���ܣ�������꽻����ͼ
********************************************************************/
#include <windows.h>
#include <windowsx.h>
#include "easydraw.h"

BOOL InitWindow (HINSTANCE hInstance, int nCmdShow);
LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain (HINSTANCE hInstance,         
                    HINSTANCE hPrevInstance,     
                    PSTR szCmdLine,              
                    int iCmdShow)                
{
	MSG msg;

	if (!InitWindow (hInstance, iCmdShow))
	return FALSE;

	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage (&msg);
		DispatchMessage (&msg);
	}

	return msg.wParam;
}

static BOOL InitWindow (HINSTANCE hInstance, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT ("EasyDraw");  
	HWND hwnd;   
	WNDCLASS wc;

	wc.style = CS_VREDRAW | CS_HREDRAW;
	wc.lpfnWndProc = WinProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 4;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon (hInstance, IDI_APPLICATION);
	wc.hCursor = LoadCursor (NULL, IDC_CROSS);
	wc.hbrBackground = GetStockObject (WHITE_BRUSH);
	wc.lpszMenuName = szAppName;
	wc.lpszClassName = szAppName;

	if (!RegisterClass (&wc))
	{
		MessageBox (NULL, TEXT ("ע�ᴰ����ʧ�ܣ�"), szAppName,
                    MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow (szAppName, TEXT ("�򵥻�ͼ����"), 
                     	WS_OVERLAPPEDWINDOW,    
                        CW_USEDEFAULT, CW_USEDEFAULT,  
                        CW_USEDEFAULT, CW_USEDEFAULT,  
                        NULL, NULL, hInstance, NULL);

	if( !hwnd ) return FALSE;

	ShowWindow( hwnd, iCmdShow );
	UpdateWindow( hwnd );
	return TRUE;
}

typedef struct tagDRAWDATA
{
    int		iSelectionFunc;
    int		iSelectionPen;
    int		iSelectionBrush;
	HPEN	hRedDashdotPen;
	HPEN	hBlueSolidPen;
    int		cxBeginPoint;
	int		cyBeginPoint;
	int		cxCurrPoint;
	int		cyCurrPoint;
	BOOL	bDrawing;
}DRAWDATA;

LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HDC           hdc;
	PAINTSTRUCT   ps;
	RECT          rect;
	LOGPEN        logpen;
	HMENU         hMenu;
    static int    iSelectionFunc = IDM_FUNC_LINETO ;
    static int    iSelectionPen = IDM_PEN_BLACK ;
    static int    iSelectionBrush = IDM_BRUSH_WHITE ;
	static HPEN   hRedDashdotPen, hBlueSolidPen;
    static int    cxBeginPoint, cyBeginPoint,cxCurrPoint, cyCurrPoint;
	static BOOL   bDrawing;
	HPEN          hOldPen;
	HBRUSH        hNewBrush, hOldBrush;
	DRAWDATA*	pDrawData;
	switch (message)
	{
	case WM_CREATE: 
		//������ɫ�㻮�߻���
		hRedDashdotPen = CreatePen (PS_DASHDOT, 1, RGB (255, 0, 0));			
			
		//��������Ϊ3����ɫ����
		logpen.lopnStyle = PS_SOLID;
		logpen.lopnWidth.x = 3;
		logpen.lopnColor = RGB (0, 0, 255); 
		hBlueSolidPen = CreatePenIndirect (&logpen);
		pDrawData = new DRAWDATA;
		pDrawData->iSelectionBrush = IDM_BRUSH_WHITE;
		// ...
		if (pDrawData)
		{
			SetWindowLong(hWnd, 0, (LONG)pDrawData);
		}
		return 0;

	case WM_COMMAND:
        hMenu = GetMenu (hWnd) ;
          
        switch (LOWORD (wParam))
        {
        case IDM_FILE_EXIT:
            SendMessage (hWnd, WM_CLOSE, 0, 0) ;
            return 0 ;
               
        case IDM_FUNC_LINETO:
        case IDM_FUNC_RECTANGLE:
        case IDM_FUNC_ELLIPSE:
            CheckMenuItem (hMenu, iSelectionFunc, MF_UNCHECKED) ;
            iSelectionFunc = LOWORD (wParam) ;
            CheckMenuItem (hMenu, iSelectionFunc, MF_CHECKED) ;
               
            InvalidateRect (hWnd, NULL, TRUE) ;
            return 0 ;
               
        case IDM_PEN_BLACK:
        case IDM_PEN_REDDASHDOT:
        case IDM_PEN_BLUESOLID: 
              
            CheckMenuItem (hMenu, iSelectionPen, MF_UNCHECKED) ;
            iSelectionPen = LOWORD (wParam) ;
            CheckMenuItem (hMenu, iSelectionPen, MF_CHECKED) ;
               
            InvalidateRect (hWnd, NULL, TRUE) ;
            return 0 ;
               
        case IDM_BRUSH_WHITE:
        case IDM_BRUSH_LTGRAY:
        case IDM_BRUSH_COLORSOLID: 
        case IDM_BRUSH_CROSS:
             
            CheckMenuItem (hMenu, iSelectionBrush, MF_UNCHECKED) ;
            iSelectionBrush = LOWORD (wParam) ;
            CheckMenuItem (hMenu, iSelectionBrush , MF_CHECKED) ;
               
            InvalidateRect (hWnd, NULL, TRUE) ;
            return 0 ;

		case IDM_ABOUT:
            MessageBox (hWnd, TEXT ("�򵥻�ͼ���򣺽���ʽ���ƻ���ͼ��"),
                        TEXT ("�򵥻�ͼ����"), MB_OK | MB_ICONINFORMATION) ;
            return 0 ;
        }
		
    case WM_LBUTTONDOWN:
        if (!bDrawing)
	        SetCapture (hWnd);

		//���ڿͻ������
		hdc = GetDC (hWnd);
		GetClientRect (hWnd, &rect);
		FillRect (hdc, &rect, GetStockObject(WHITE_BRUSH));
		ReleaseDC (hWnd, hdc);

		//���û�ͼ����ʼ����ֹ��
		cxBeginPoint = LOWORD (lParam);
        cyBeginPoint = HIWORD (lParam);
		cxCurrPoint = LOWORD (lParam);
		cyCurrPoint = HIWORD (lParam);
        
		//���ÿ�ʼ��ͼ��־
		bDrawing = TRUE;
        return 0;

    case WM_LBUTTONUP:
        if (bDrawing)
            SetCapture (NULL);
        bDrawing = FALSE ;
        return 0 ;

    case WM_MOUSEMOVE:

        if (!bDrawing)
            return 0 ;
		
        //ѡ���»���
		hdc = GetDC (hWnd) ;

		switch (iSelectionPen)
		{
		case IDM_PEN_BLACK:
			hOldPen = SelectObject (hdc, GetStockObject(BLACK_PEN));
			break;
		case IDM_PEN_REDDASHDOT:
			hOldPen = SelectObject (hdc, hRedDashdotPen);
			break;
		case IDM_PEN_BLUESOLID:
			hOldPen = SelectObject (hdc, hBlueSolidPen);
			break;
		}

        //ѡ���»�ˢ
		switch (iSelectionBrush)
		{
		case IDM_BRUSH_WHITE:
			hOldBrush = SelectObject (hdc, GetStockObject(WHITE_BRUSH));
			break;
		case IDM_BRUSH_LTGRAY:
			hOldBrush = SelectObject (hdc, GetStockObject(LTGRAY_BRUSH));
			break;
		case IDM_BRUSH_COLORSOLID:
			//������ѡ���ɫʵ�廭ˢ
			hNewBrush = CreateSolidBrush (RGB (0, 255, 255));
			hOldBrush = SelectObject (hdc, hNewBrush);
			break;
		case IDM_BRUSH_CROSS:
			//������ѡ����ɫʮ��Ӱ�߻�ˢ
			hNewBrush = CreateHatchBrush (HS_CROSS, RGB (0, 255, 0));
			hOldBrush = SelectObject (hdc, hNewBrush);
			break;
		}

		//���ԭ��ͼ�켣  ----liang
		if (cxBeginPoint < cxCurrPoint)
		{
			rect.left  = cxBeginPoint-3;
			rect.right = cxCurrPoint+3;
		}
		else
		{
			rect.left = cxCurrPoint-3;
			rect.right= cxBeginPoint+3;
		}
		if (cyBeginPoint < cyCurrPoint)
		{
			rect.top   = cyBeginPoint-3;
			rect.bottom= cyCurrPoint+3;
		}
		else
		{
			rect.top   = cyCurrPoint-3;
			rect.bottom= cyBeginPoint+3;
		}
		FillRect (hdc, &rect, GetStockObject(WHITE_BRUSH));
		//  ---- liang

//		//���ԭ��ͼ�켣
//		SetROP2 (hdc, R2_WHITE);
//
//		switch (iSelectionFunc)
//		{
//		case IDM_FUNC_LINETO:
//			MoveToEx (hdc, cxBeginPoint, cyBeginPoint, NULL);
//			LineTo (hdc, cxCurrPoint, cyCurrPoint);
//			break;
//
//		case IDM_FUNC_RECTANGLE:
//			Rectangle (hdc, cxBeginPoint, cyBeginPoint, 
//					   cxCurrPoint, cyCurrPoint);
//			break;
//
//		case IDM_FUNC_ELLIPSE:
//			Ellipse (hdc, cxBeginPoint, cyBeginPoint, 
//					 cxCurrPoint, cyCurrPoint);
//			break;
//		}
		
        cxCurrPoint = (short) LOWORD (lParam) ;
        cyCurrPoint = (short) HIWORD (lParam) ;

        //��ͼ�¹켣
		SetROP2 (hdc, R2_COPYPEN);

		switch (iSelectionFunc)
		{
		case IDM_FUNC_LINETO:
			MoveToEx (hdc, cxBeginPoint, cyBeginPoint, NULL);
			LineTo (hdc, cxCurrPoint, cyCurrPoint);
			break;

		case IDM_FUNC_RECTANGLE:
			Rectangle (hdc, cxBeginPoint, cyBeginPoint, 
				       cxCurrPoint, cyCurrPoint);
			break;

		case IDM_FUNC_ELLIPSE:
			Ellipse (hdc, cxBeginPoint, cyBeginPoint, 
				     cxCurrPoint, cyCurrPoint);
			break;

		}

		//���ʡ���ˢ��ԭ
		SelectObject (hdc, hOldPen);
		SelectObject (hdc, hOldBrush);

		//ɾ���Խ���ˢ
		DeleteObject (hNewBrush);

        ReleaseDC (hWnd, hdc) ;
        return 0 ;

	case WM_PAINT://�����ػ���Ϣ
		hdc=BeginPaint (hWnd, &ps);            //ȡ���豸�������
		EndPaint ( hWnd, &ps ); 
		return 0;

	case WM_DESTROY:      
		//ɾ���Խ�����
		DeleteObject (hRedDashdotPen);
		DeleteObject (hBlueSolidPen);
		pDrawData = (DRAWDATA*)GetWindowLong(hWnd, 0);
		if (pDrawData) delete pDrawData;
		
		PostQuitMessage (0); 
		return 0;
	}

	return DefWindowProc (hWnd, message, wParam, lParam);

}

