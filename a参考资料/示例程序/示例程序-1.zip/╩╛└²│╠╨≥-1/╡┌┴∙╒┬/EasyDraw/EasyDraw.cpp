/*******************************************************************
程序：EasyDraw
文件：EasyDraw.c
功能：利用鼠标交互绘图
********************************************************************/
#include <windows.h>
#include <windowsx.h>
#include "easydraw.h"

BOOL InitWindow (HINSTANCE hInstance, int nCmdShow);
LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain (HINSTANCE hInstance,         
                    HINSTANCE hPrevInstance,     
                    PSTR szCmdLine,              
                    int iCmdShow)                
{
	MSG msg;

	if (!InitWindow (hInstance, iCmdShow))
	return FALSE;

	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage (&msg);
		DispatchMessage (&msg);
	}

	return msg.wParam;
}

static BOOL InitWindow (HINSTANCE hInstance, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT ("EasyDraw");  
	HWND hwnd;   
	WNDCLASS wc;

	wc.style = CS_VREDRAW | CS_HREDRAW;
	wc.lpfnWndProc = WinProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 4;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon (hInstance, IDI_APPLICATION);
	wc.hCursor = LoadCursor (NULL, IDC_CROSS);
	wc.hbrBackground = (HBRUSH)GetStockObject (WHITE_BRUSH);
	wc.lpszMenuName = szAppName;
	wc.lpszClassName = szAppName;

	if (!RegisterClass (&wc))
	{
		MessageBox (NULL, TEXT ("注册窗口类失败！"), szAppName,
                    MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow (szAppName, TEXT ("简单绘图程序"), 
                     	WS_OVERLAPPEDWINDOW,    
                        CW_USEDEFAULT, CW_USEDEFAULT,  
                        CW_USEDEFAULT, CW_USEDEFAULT,  
                        NULL, NULL, hInstance, NULL);

	if( !hwnd ) return FALSE;

	ShowWindow( hwnd, iCmdShow );
	UpdateWindow( hwnd );
	return TRUE;
}

typedef struct tagDRAWDATA
{
    int		iSelectionFunc;
    int		iSelectionPen;
    int		iSelectionBrush;
	HPEN	hRedDashdotPen;
	HPEN	hBlueSolidPen;
    int		cxBeginPoint;
	int		cyBeginPoint;
	int		cxCurrPoint;
	int		cyCurrPoint;
	BOOL	bDrawing;
}DRAWDATA;

LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HDC           hdc;
	PAINTSTRUCT   ps;
	RECT          rect;
	LOGPEN        logpen;
	HMENU         hMenu;
    static int    iSelectionFunc = IDM_FUNC_LINETO ;
    static int    iSelectionPen = IDM_PEN_BLACK ;
    static int    iSelectionBrush = IDM_BRUSH_WHITE ;
	static HPEN   hRedDashdotPen, hBlueSolidPen;
    static int    cxBeginPoint, cyBeginPoint,cxCurrPoint, cyCurrPoint;
	static BOOL   bDrawing;
	HPEN          hOldPen;
	HBRUSH        hNewBrush, hOldBrush;
	DRAWDATA*	pDrawData = NULL;
	switch (message)
	{
	case WM_CREATE: 
		//创建红色点划线画笔
		hRedDashdotPen = CreatePen (PS_DASHDOT, 1, RGB (255, 0, 0));			
			
		//创建宽度为3的蓝色画笔
		logpen.lopnStyle = PS_SOLID;
		logpen.lopnWidth.x = 3;
		logpen.lopnColor = RGB (0, 0, 255); 
		hBlueSolidPen = CreatePenIndirect (&logpen);
		pDrawData = new DRAWDATA;
		pDrawData->iSelectionBrush = IDM_BRUSH_WHITE;
		// ...
		if (pDrawData)
		{
			SetWindowLong(hWnd, 0, (LONG)pDrawData);
		}
		return 0;

	case WM_COMMAND:
        hMenu = GetMenu (hWnd) ;
          
        switch (LOWORD (wParam))
        {
        case IDM_FILE_EXIT:
            SendMessage (hWnd, WM_CLOSE, 0, 0) ;
            return 0 ;
               
        case IDM_FUNC_LINETO:
        case IDM_FUNC_RECTANGLE:
        case IDM_FUNC_ELLIPSE:
            CheckMenuItem (hMenu, iSelectionFunc, MF_UNCHECKED) ;
            iSelectionFunc = LOWORD (wParam) ;
            CheckMenuItem (hMenu, iSelectionFunc, MF_CHECKED) ;
               
            InvalidateRect (hWnd, NULL, TRUE) ;
            return 0 ;
               
        case IDM_PEN_BLACK:
        case IDM_PEN_REDDASHDOT:
        case IDM_PEN_BLUESOLID: 
              
            CheckMenuItem (hMenu, iSelectionPen, MF_UNCHECKED) ;
            iSelectionPen = LOWORD (wParam) ;
            CheckMenuItem (hMenu, iSelectionPen, MF_CHECKED) ;
               
            InvalidateRect (hWnd, NULL, TRUE) ;
            return 0 ;
               
        case IDM_BRUSH_WHITE:
        case IDM_BRUSH_LTGRAY:
        case IDM_BRUSH_COLORSOLID: 
        case IDM_BRUSH_CROSS:
             
            CheckMenuItem (hMenu, iSelectionBrush, MF_UNCHECKED) ;
            iSelectionBrush = LOWORD (wParam) ;
            CheckMenuItem (hMenu, iSelectionBrush , MF_CHECKED) ;
               
            InvalidateRect (hWnd, NULL, TRUE) ;
            return 0 ;

		case IDM_ABOUT:
            MessageBox (hWnd, TEXT ("简单绘图程序：交互式绘制基本图形"),
                        TEXT ("简单绘图程序"), MB_OK | MB_ICONINFORMATION) ;
            return 0 ;
        }
		
    case WM_LBUTTONDOWN:
        if (!bDrawing)
	        SetCapture (hWnd);

		//窗口客户区清空
		hdc = GetDC (hWnd);
		GetClientRect (hWnd, &rect);
		FillRect (hdc, &rect, (HBRUSH)GetStockObject(WHITE_BRUSH));
		ReleaseDC (hWnd, hdc);

		//设置绘图的起始、终止点
		cxBeginPoint = LOWORD (lParam);
        cyBeginPoint = HIWORD (lParam);
		cxCurrPoint = LOWORD (lParam);
		cyCurrPoint = HIWORD (lParam);
        
		//设置开始绘图标志
		bDrawing = TRUE;
        return 0;

    case WM_LBUTTONUP:
        if (bDrawing)
            SetCapture (NULL);
        bDrawing = FALSE ;
        return 0 ;

    case WM_MOUSEMOVE:

        if (!bDrawing)
            return 0 ;
		
        //选用新画笔
		hdc = GetDC (hWnd) ;

		switch (iSelectionPen)
		{
		case IDM_PEN_BLACK:
			hOldPen = (HPEN)SelectObject (hdc, (HPEN)GetStockObject(BLACK_PEN));
			break;
		case IDM_PEN_REDDASHDOT:
			hOldPen = (HPEN)SelectObject (hdc, (HPEN)hRedDashdotPen);
			break;
		case IDM_PEN_BLUESOLID:
			hOldPen = (HPEN)SelectObject (hdc, (HPEN)hBlueSolidPen);
			break;
		}

        //选用新画刷
		switch (iSelectionBrush)
		{
		case IDM_BRUSH_WHITE:
			hOldBrush = (HBRUSH)SelectObject (hdc, GetStockObject(WHITE_BRUSH));
			break;
		case IDM_BRUSH_LTGRAY:
			hOldBrush = (HBRUSH)SelectObject (hdc, GetStockObject(LTGRAY_BRUSH));
			break;
		case IDM_BRUSH_COLORSOLID:
			//创建并选择彩色实体画刷
			hNewBrush = (HBRUSH)CreateSolidBrush (RGB (0, 255, 255));
			hOldBrush = (HBRUSH)SelectObject (hdc, hNewBrush);
			break;
		case IDM_BRUSH_CROSS:
			//创建并选择绿色十字影线画刷
			hNewBrush = (HBRUSH)CreateHatchBrush (HS_CROSS, RGB (0, 255, 0));
			hOldBrush = (HBRUSH)SelectObject (hdc, hNewBrush);
			break;
		}

		//清除原绘图轨迹  ----liang
		if (cxBeginPoint < cxCurrPoint)
		{
			rect.left  = cxBeginPoint-3;
			rect.right = cxCurrPoint+3;
		}
		else
		{
			rect.left = cxCurrPoint-3;
			rect.right= cxBeginPoint+3;
		}
		if (cyBeginPoint < cyCurrPoint)
		{
			rect.top   = cyBeginPoint-3;
			rect.bottom= cyCurrPoint+3;
		}
		else
		{
			rect.top   = cyCurrPoint-3;
			rect.bottom= cyBeginPoint+3;
		}
		FillRect (hdc, &rect, (HBRUSH)GetStockObject(WHITE_BRUSH));
		//  ---- liang

//		//清除原绘图轨迹
//		SetROP2 (hdc, R2_WHITE);
//
//		switch (iSelectionFunc)
//		{
//		case IDM_FUNC_LINETO:
//			MoveToEx (hdc, cxBeginPoint, cyBeginPoint, NULL);
//			LineTo (hdc, cxCurrPoint, cyCurrPoint);
//			break;
//
//		case IDM_FUNC_RECTANGLE:
//			Rectangle (hdc, cxBeginPoint, cyBeginPoint, 
//					   cxCurrPoint, cyCurrPoint);
//			break;
//
//		case IDM_FUNC_ELLIPSE:
//			Ellipse (hdc, cxBeginPoint, cyBeginPoint, 
//					 cxCurrPoint, cyCurrPoint);
//			break;
//		}
		
        cxCurrPoint = (short) LOWORD (lParam) ;
        cyCurrPoint = (short) HIWORD (lParam) ;

        //绘图新轨迹
		SetROP2 (hdc, R2_COPYPEN);

		switch (iSelectionFunc)
		{
		case IDM_FUNC_LINETO:
			MoveToEx (hdc, cxBeginPoint, cyBeginPoint, NULL);
			LineTo (hdc, cxCurrPoint, cyCurrPoint);
			break;

		case IDM_FUNC_RECTANGLE:
			Rectangle (hdc, cxBeginPoint, cyBeginPoint, 
				       cxCurrPoint, cyCurrPoint);
			break;

		case IDM_FUNC_ELLIPSE:
			Ellipse (hdc, cxBeginPoint, cyBeginPoint, 
				     cxCurrPoint, cyCurrPoint);
			break;

		}

		//画笔、画刷还原
		SelectObject (hdc, hOldPen);
		SelectObject (hdc, hOldBrush);

		//删除自建画刷
		DeleteObject (hNewBrush);

        ReleaseDC (hWnd, hdc) ;
        return 0 ;

	case WM_PAINT://窗口重画消息
		hdc=BeginPaint (hWnd, &ps);            //取得设备环境句柄
		EndPaint ( hWnd, &ps ); 
		return 0;

	case WM_DESTROY:      
		//删除自建画笔
		DeleteObject (hRedDashdotPen);
		DeleteObject (hBlueSolidPen);
		pDrawData = (DRAWDATA*)GetWindowLong(hWnd, 0);
		if (pDrawData) delete pDrawData;
		
		PostQuitMessage (0); 
		return 0;
	}

	return DefWindowProc (hWnd, message, wParam, lParam);

}

