/*-----------------------------------------------
   SYSMETS.H -- System metrics display structure
  -----------------------------------------------*/
#define MAXCHOOSEFONTSNUM  5
//#define NUMLINES ((int) (sizeof fontmetrics / sizeof fontmetrics [0]))

struct
{
     TCHAR * szlfFaceName;
     LONG    lfHeight;
     LONG    lfWidth;
}fontmetrics [MAXCHOOSEFONTSNUM];
