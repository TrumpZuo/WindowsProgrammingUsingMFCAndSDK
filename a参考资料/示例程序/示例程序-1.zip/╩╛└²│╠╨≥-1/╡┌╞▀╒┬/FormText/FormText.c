/*******************************************************************
����FormText
�ļ���FormText.c
���ܣ���ʽ���ı���ʾ����
********************************************************************/
#include <windows.h>
#include <windowsx.h>

BOOL InitWindow (HINSTANCE hInstance, int nCmdShow);
LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow)
{
	MSG msg;

	if (!InitWindow (hInstance, iCmdShow))
	return FALSE;

	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage (&msg);
		DispatchMessage (&msg);
	}

	return msg.wParam;
}

static BOOL InitWindow (HINSTANCE hInstance, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT ("FormText");
	HWND hwnd;   
	WNDCLASS wc; 

	wc.style = CS_VREDRAW | CS_HREDRAW | CS_DBLCLKS;
	wc.lpfnWndProc = WinProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon (hInstance, IDI_APPLICATION);
	wc.hCursor = LoadCursor (NULL, IDC_ARROW);
	wc.hbrBackground = GetStockObject (WHITE_BRUSH);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = szAppName;

	if (!RegisterClass (&wc))
	{
		MessageBox (NULL, TEXT ("ע�ᴰ����ʧ�ܣ�"), szAppName,
                    MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow (szAppName, 
	                    TEXT ("��ʽ���ı���ʾ����"),
                     	WS_OVERLAPPEDWINDOW,
                        CW_USEDEFAULT, CW_USEDEFAULT, 
                        CW_USEDEFAULT, CW_USEDEFAULT,
                        NULL, NULL, hInstance, NULL); 

	if( !hwnd ) return FALSE;

	ShowWindow( hwnd, iCmdShow );
	UpdateWindow( hwnd );
	return TRUE;
}

LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static CHOOSECOLOR  cc;
	static COLORREF     crCustomColors[16];
	static COLORREF     crText = RGB (0, 0, 0);
    static CHOOSEFONT   cf;
	static LOGFONT      logfont;
	static HFONT        hFont;
	static TCHAR *      szlfFaceName;
	int                 cxChar, cyChar, x, y;
	TCHAR               szBuffer[5];
	TEXTMETRIC          tm;
	HDC                 hdc;
	PAINTSTRUCT         ps;
	RECT                rect;

	switch (message)
	{
		case WM_CREATE:
			//��ʼ���ṹ cc
			cc.lStructSize    = sizeof (CHOOSECOLOR);
			cc.hwndOwner      = hWnd;
			cc.hInstance      = NULL;
			cc.rgbResult      = RGB (0, 0, 0);
			cc.lpCustColors   = crCustomColors;
			cc.Flags          = CC_RGBINIT | CC_FULLOPEN;
			cc.lCustData      = 0;
			cc.lpfnHook       = NULL;
			cc.lpTemplateName = NULL;

			//��ʼ���ṹ cf

		    GetObject (GetStockObject (SYSTEM_FONT), sizeof (LOGFONT), 
					   (PTSTR) &logfont);        //��ʼ���ṹ logfont

			cf.lStructSize    = sizeof (CHOOSEFONT);
			cf.hwndOwner      = hWnd;
			cf.hDC            = NULL;
			cf.lpLogFont      = &logfont;
			cf.iPointSize     = 0;
			cf.Flags          = CF_INITTOLOGFONTSTRUCT | CF_SCREENFONTS | CF_EFFECTS;
			cf.rgbColors      = 0;
			cf.lCustData      = 0;
		    cf.lpfnHook       = NULL;
			cf.lpTemplateName = NULL;
			cf.hInstance      = NULL;
		    cf.lpszStyle      = NULL;
			cf.nFontType      = 0;
			cf.nSizeMin       = 0;
		    cf.nSizeMax       = 0;
     
			szlfFaceName = logfont.lfFaceName;
	
			return 0;

		case WM_RBUTTONUP:
			//�򿪡���ɫ��ͨ�öԻ���ѡ����ɫ���ӵ��Զ�����ɫ��
			if (ChooseColor (&cc))
			{
				crText = crCustomColors[0];
				InvalidateRect (hWnd, NULL, TRUE);
			}
			
			return 0;

		case WM_LBUTTONDBLCLK:
			//�򿪡� ���塱ͨ�öԻ���ѡ�����岢�Դ˴����߼�����
			if (ChooseFont (&cf))
			{
			    if (hFont)  DeleteObject (hFont);

				szlfFaceName = logfont.lfFaceName;

				hFont = CreateFontIndirect (&logfont);

				InvalidateRect (hWnd, NULL, TRUE);
			}
			
			return 0;

		case WM_PAINT: 
			hdc = BeginPaint (hWnd, &ps); 
			GetClientRect (hWnd, &rect);

			if (hFont) SelectObject (hdc, hFont);              //ѡ���߼�����

			SetTextColor (hdc, crText);

			GetTextMetrics (hdc, &tm) ;
			cxChar = tm.tmAveCharWidth ;
			cyChar = tm.tmHeight + tm.tmExternalLeading ;
          
            x = cxChar;
            y = cyChar;
               
            TextOut (hdc, x, y, TEXT ("�������ƣ�"), lstrlen (TEXT ("�������ƣ�")));
              
            SetTextAlign (hdc, TA_RIGHT | TA_TOP) ;
               
            TextOut (hdc, x + (lstrlen (szlfFaceName) + 30) * cxChar, y,
				szlfFaceName, lstrlen (szlfFaceName));
              
            SetTextAlign (hdc, TA_LEFT | TA_TOP) ;
			
            y = 3 * cyChar;
               
            TextOut (hdc, x, y, TEXT ("�ַ���Ԫ�߶ȣ�"), lstrlen (TEXT ("�ַ���Ԫ�߶ȣ�")));
              
            SetTextAlign (hdc, TA_RIGHT | TA_TOP) ;
               
            TextOut (hdc, x + (lstrlen (szlfFaceName) + 30) * cxChar, y,
				szBuffer, wsprintf (szBuffer, TEXT ("%5d"), cyChar));
              
            SetTextAlign (hdc, TA_LEFT | TA_TOP) ;
			
            y = 5 * cyChar;
               
            TextOut (hdc, x, y, TEXT ("�ַ�ƽ�����ȣ�"), lstrlen (TEXT ("�ַ�ƽ�����ȣ�")));
              
            SetTextAlign (hdc, TA_RIGHT | TA_TOP) ;
               
            TextOut (hdc, x + (lstrlen (szlfFaceName) + 30) * cxChar, y,
				szBuffer, wsprintf (szBuffer, TEXT ("%5d"), cxChar));
              
            SetTextAlign (hdc, TA_LEFT | TA_TOP) ;
			
			SelectObject (hdc, GetStockObject (SYSTEM_FONT));  //��ԭ�߼�����

			EndPaint (hWnd, &ps);
			return 0;

		case WM_DESTROY: 
		    if (hFont)  DeleteObject (hFont);       //ɾ���߼�����
			PostQuitMessage (0);
			return 0;
	}

	return DefWindowProc (hWnd, message, wParam, lParam);

} //���� WinProc ����

