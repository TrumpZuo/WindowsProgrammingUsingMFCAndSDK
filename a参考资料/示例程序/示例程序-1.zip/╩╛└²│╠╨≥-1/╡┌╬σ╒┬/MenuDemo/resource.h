//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MenuDemo.rc
//
#define IDI_ICON1                       101
#define IDB_BITMAP1                     103
#define IDR_MENU1                       104
#define IDC_CURSOR1                     105
#define IDD_DIALOG_CHANGEBKCOLOR        106
#define IDD_DLG_INPUTDATA               107
#define IDC_BUT_SELCOLOR                1001
#define IDC_RADIO_RED                   1002
#define IDC_RADIO_GREEN                 1003
#define IDC_RADIO_YELLOW                1004
#define IDC_COLORVALUE                  1005
#define IDC_EDIT_INPUT                  1006
#define ID_MENUITEM40001                40001
#define ID_MENUITEM40002                40002
#define IDM_SET_BKColor                 40003
#define IDM_EDIT_OTHERINPUT             40004
#define ID_MENUITEM40005                40005
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
