/*******************************************************************
����MenuDemo
�ļ���MenuDemo.c
���ܣ��˵���ʾ���򡪴������˵����ļ����ı��༭��
********************************************************************/
#include <windows.h>
#include <windowsx.h>
#include "menudemo.h"
#include "resource.h"

LRESULT CALLBACK MainWndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
char g_EditInput[1024];
COLORREF GetMyColor(HWND hWnd)
{
	// �����Զ���Ի���
	
	COLORREF	 cr = 0;
	CHOOSECOLOR  cc;
	COLORREF     crCustomColors[16];
	
	//��ʼ��CHOOSECOLOR�ṹ���� cc
	cc.lStructSize    = sizeof (CHOOSECOLOR);
	cc.hwndOwner      = hWnd;
	cc.hInstance      = NULL;
	cc.rgbResult      = RGB (0, 0, 0);
	cc.lpCustColors   = crCustomColors;
	cc.Flags          = CC_RGBINIT | CC_FULLOPEN;
	cc.lCustData      = 0;
	cc.lpfnHook       = NULL;
	cc.lpTemplateName = NULL;
	
	if (ChooseColor (&cc))
		cr = cc.rgbResult;
	return cr;
};

COLORREF g_Color;
BOOL CALLBACK ColorDlgProc (HWND hDlg, UINT message, 
							WPARAM wParam, LPARAM lParam)
{
	BOOL b;
    static int  iColor;             //�û�ѡ�����ɫ
    switch (message)
    {
    case WM_INITDIALOG:
		//������Ϊ��ɫ
        CheckRadioButton (hDlg, IDC_RADIO_RED, IDC_RADIO_GREEN, IDC_RADIO_RED);
        SetDlgItemInt (hDlg, IDC_COLORVALUE, RGB(255,0,0), FALSE);
        return FALSE;
		
    case WM_COMMAND:
		//�����Ի����и��ؼ�֪ͨ��Ϣ
        switch (LOWORD (wParam))
        {
        case IDOK:
			//��Ӧ"ȷ��"��ť����д�ı���ɫ iCurrentColor ΪiColor
            g_Color = GetDlgItemInt(hDlg, IDC_COLORVALUE, &b, FALSE);
			
            //�رնԻ���
            EndDialog (hDlg, TRUE);      //�رնԻ���
            return TRUE;
			
        case IDCANCEL:
			//��Ӧ"ȡ��"��ť��ֱ�ӹرնԻ���
            EndDialog (hDlg, FALSE);
            return TRUE;
		case IDC_BUT_SELCOLOR:
			SetDlgItemInt(hDlg, IDC_COLORVALUE, GetMyColor(hDlg), FALSE);
			return TRUE;

        case IDC_RADIO_RED:
        case IDC_RADIO_GREEN:
        case IDC_RADIO_YELLOW:
            CheckRadioButton (hDlg, IDC_RADIO_RED, IDC_RADIO_YELLOW, LOWORD (wParam));
			switch(LOWORD (wParam))
			{
			case IDC_RADIO_RED: SetDlgItemInt (hDlg, IDC_COLORVALUE, RGB(255,0,0), FALSE); break;
			case IDC_RADIO_GREEN: SetDlgItemInt (hDlg, IDC_COLORVALUE, RGB(0,255,0), FALSE); break;
			case IDC_RADIO_YELLOW: SetDlgItemInt (hDlg, IDC_COLORVALUE, RGB(255,255,0), FALSE); break;
			}
            return TRUE;
        }
        break;
    }
    return FALSE;
};//���� ColorDlgProc


BOOL CALLBACK InputDlgProc (HWND hDlg, UINT message, 
							WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_INITDIALOG:
		SetDlgItemText(hDlg, IDC_EDIT_INPUT, "FormerText");
        return FALSE;
		
    case WM_COMMAND:
		//�����Ի����и��ؼ�֪ͨ��Ϣ
        switch (LOWORD (wParam))
        {
        case IDOK:
			//��Ӧ"ȷ��"��ť����д�ı���ɫ iCurrentColor ΪiColor
            GetDlgItemText(hDlg, IDC_EDIT_INPUT, g_EditInput,1024);
			
            //�رնԻ���
            EndDialog (hDlg, TRUE);      //�رնԻ���
            return TRUE;
			
        case IDCANCEL:
			//��Ӧ"ȡ��"��ť��ֱ�ӹرնԻ���
            EndDialog (hDlg, FALSE);
            return TRUE;
        }
        break;
    }
    return FALSE;
};//���� InputDlgProc


int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT ("MenuDemo");
	HWND         hwnd;   
	WNDCLASS     wc;
	MSG          msg;
	HACCEL       hAccel;

	wc.style = CS_VREDRAW | CS_HREDRAW;
	wc.lpfnWndProc = MainWndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon (hInstance, IDI_APPLICATION);
	wc.hCursor = LoadCursor (hInstance, MAKEINTRESOURCE(IDC_CURSOR1));
	//wc.hCursor = LoadCursor (NULL, IDC_ARROW);
	wc.hbrBackground = GetStockObject (WHITE_BRUSH);
	wc.lpszMenuName = szAppName;	// NULL;
	wc.lpszClassName = szAppName;

	if (!RegisterClass (&wc))
	{
		MessageBox (NULL, TEXT ("ע�ᴰ����ʧ�ܣ�"), szAppName,
                    MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow (szAppName, 
	                    TEXT ("�˵���ʾ���򡪴������˵����ļ����ı��༭��"),
                     	WS_OVERLAPPEDWINDOW,
                        CW_USEDEFAULT, 
                        CW_USEDEFAULT, 
                        CW_USEDEFAULT,
                        CW_USEDEFAULT,
                        NULL, 
						//		LoadMenu(hInstance, MAKEINTRESOURCE(IDR_MENU1)),
						NULL,
                        hInstance, 
                        NULL);
	
	if( !hwnd ) return FALSE;

	ShowWindow ( hwnd, iCmdShow );
	UpdateWindow ( hwnd );

	hAccel = LoadAccelerators (hInstance, szAppName);
	if (!hAccel)
	{
		MessageBeep(0);
		return FALSE;
	}

	while (GetMessage (&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator (hwnd, hAccel, &msg))
		{
			TranslateMessage (&msg);
			DispatchMessage (&msg);
		}
	}

	return msg.wParam;
}

LRESULT CALLBACK MainWndProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static HWND  hWndEdit;
	HBRUSH hOld;
	static BOOL bChange=FALSE;

	PAINTSTRUCT ps;
    int          nSelected, nEnable;
	HANDLE hIcon;	HANDLE hCur;	  HANDLE hBitmap,hOldBitmap;
	HANDLE hdcMem;
	static HANDLE hMenuPop;
	POINT pt;
	
	switch (message)
	{
	case WM_CREATE:
		hWndEdit=CreateWindow (TEXT ("edit"),			        //��������
							  NULL,			                    //�ޱ���
							  WS_CHILD|WS_VISIBLE|WS_HSCROLL|	//�༭�ؼ����
							  WS_VSCROLL|WS_BORDER|ES_LEFT|
							  ES_MULTILINE|ES_AUTOHSCROLL|
							  ES_AUTOVSCROLL,
							  0,0,0,0,	
							  hWnd,		                        //�����ھ��
							  (HMENU)1,		                    //�༭�ؼ��Ӵ��ڱ�ʶ
							  (HINSTANCE) GetWindowLong (hWnd, GWL_HINSTANCE),
							  NULL);
		hMenuPop = LoadMenu (((LPCREATESTRUCT)lParam)->hInstance, "MENUDEMO");
		hMenuPop = GetSubMenu (hMenuPop, 2);
		
		return 0;

	case WM_SETFOCUS:
		SetFocus (hWndEdit);
		return 0;
						// LiangCH
	case WM_PAINT:
		BeginPaint(hWnd, &ps);
		hIcon = LoadIcon ((HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), MAKEINTRESOURCE (IDI_ICON1));
		DrawIcon (ps.hdc, 0, 0, hIcon);

		hCur = LoadCursor (NULL, IDC_HELP);
		DrawIcon (ps.hdc, 50, 0, hCur);

		hIcon = LoadIcon (NULL, IDI_APPLICATION);
		DrawIcon (ps.hdc, 90, 0, hIcon);
		hIcon = LoadIcon (NULL, IDI_ASTERISK);
		DrawIcon (ps.hdc, 130, 0, hIcon);
		hIcon = LoadIcon (NULL, IDI_QUESTION);
		DrawIcon (ps.hdc, 170, 0, hIcon);
		hIcon = LoadIcon (NULL, IDI_EXCLAMATION);
		DrawIcon (ps.hdc, 210, 0, hIcon);
		hIcon = LoadIcon (NULL, IDI_HAND);
		DrawIcon (ps.hdc, 250, 0, hIcon);
		/////////////
		hdcMem = CreateCompatibleDC (ps.hdc);
		hBitmap = LoadBitmap((HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), MAKEINTRESOURCE(IDB_BITMAP1));
		hOldBitmap = SelectObject (hdcMem, hBitmap);
		StretchBlt (ps.hdc, 300, 0, 700, 300, hdcMem, 0, 0, 400,300, SRCCOPY);
		/////////////
		EndPaint(hWnd, &ps);
		return 0;
						// LiangCH
	case WM_SIZE:
		MoveWindow (hWndEdit, 0, 300, 
					LOWORD(lParam), 
					(HIWORD(lParam)-300>0) ? HIWORD(lParam)-300:300, TRUE);
		return 0;

    case WM_INITMENUPOPUP:       //���ò˵���ʾ״̬
        if (lParam == 1)
        {
            //���á��������˵���״̬
			EnableMenuItem ((HMENU) wParam, IDM_EDIT_UNDO,
                SendMessage (hWndEdit, EM_CANUNDO, 0, 0) ?
                             MF_ENABLED : MF_GRAYED) ;
               
            //���á�ճ�����˵���״̬
            EnableMenuItem ((HMENU) wParam, IDM_EDIT_PASTE,
                IsClipboardFormatAvailable (CF_TEXT) ? MF_ENABLED : MF_GRAYED) ;
               
            nSelected = SendMessage (hWndEdit, EM_GETSEL, 0, 0) ;
               
            if (HIWORD (nSelected) == LOWORD (nSelected))
                nEnable = MF_GRAYED ;
            else
                nEnable = MF_ENABLED ;
               
            //���á����С��������ơ�������������˵���״̬
			EnableMenuItem ((HMENU) wParam, IDM_EDIT_CUT,   nEnable) ;
            EnableMenuItem ((HMENU) wParam, IDM_EDIT_COPY,  nEnable) ;
            EnableMenuItem ((HMENU) wParam, IDM_EDIT_CLEAR, nEnable) ;
            return 0 ;
		}
        break ;
    case WM_RBUTTONUP:
		pt.x = LOWORD (lParam);
		pt.y = HIWORD (lParam);
		ClientToScreen (hWnd, &pt);
		TrackPopupMenu (hMenuPop,                            //��ݲ˵����
			TPM_LEFTALIGN | TPM_TOPALIGN | TPM_LEFTBUTTON, //��־ѡ��
			pt.x, pt.y, 0, hWnd, NULL);
		return 0;
		
	case WM_COMMAND:        	// ��Ӧ�˵����༭�ؼ�֪ͨ��Ϣ
		if (lParam)
		{
			//�༭�ؼ�֪ͨ��Ϣ
			if ((LOWORD (wParam) == 1) &&
				(HIWORD(wParam) == EN_ERRSPACE || HIWORD (wParam) == EN_MAXTEXT))
				MessageBox (hWnd,TEXT ("�༭�ؼ��ڴ����"), 
							TEXT ("�˵�ʾ������"), MB_OK|MB_ICONSTOP);	
            return 0 ;
		}
		else
		{
			//�˵���Ϣ
			switch (LOWORD (wParam))
			{
			case IDM_FILE_EXIT:
				SendMessage (hWnd, WM_CLOSE, 0, 0);
				return 0 ;
               
			case IDM_SET_BKColor:			// Liangch 2004.03.25
				if (DialogBox ( (HINSTANCE)GetWindowLong (hWnd, GWL_HINSTANCE), 
							MAKEINTRESOURCE(IDD_DIALOG_CHANGEBKCOLOR), 
							hWnd, ColorDlgProc)==IDOK)
				{
					if (bChange) hOld = (HBRUSH)GetClassLong(hWnd, GCL_HBRBACKGROUND);
					SetClassLong(hWnd, GCL_HBRBACKGROUND,(LONG)CreateSolidBrush(g_Color));
					bChange = TRUE;
					if (bChange) DeleteObject(hOld);

					InvalidateRect(hWnd, NULL, TRUE);
				}
				return 0;				// Liangch 2004.03.25

			case IDM_FILE_NEW:
			case IDM_FILE_OPEN:
			case IDM_FILE_SAVE:
			case IDM_FILE_SAVEAS:
			case IDM_FILE_PRINTSETUP:
			case IDM_FILE_PRINT:
                MessageBeep (0) ;
	            MessageBox (hWnd, TEXT ("������д�������"),
                        TEXT ("�˵���ʾ����"), MB_OK | MB_ICONINFORMATION) ;
		        return 0 ;
          
			case IDM_EDIT_UNDO:
                SendMessage (hWndEdit, WM_UNDO, 0, 0) ;
                return 0 ;
          
            case IDM_EDIT_CUT:
                SendMessage (hWndEdit, WM_CUT, 0, 0) ;
                return 0 ;
          
            case IDM_EDIT_COPY:
                SendMessage (hWndEdit, WM_COPY, 0, 0) ;
                return 0 ;
          
            case IDM_EDIT_PASTE:
                SendMessage (hWndEdit, WM_PASTE, 0, 0) ;
                return 0 ;
          
            case IDM_EDIT_CLEAR:
                SendMessage (hWndEdit, WM_CLEAR, 0, 0) ;
                return 0 ;
          
            case IDM_EDIT_SELECTALL:
				SendMessage (hWndEdit, EM_SETSEL, 0, -1) ;
				return 0 ;
			case IDM_EDIT_OTHERINPUT:
				if (DialogBox( (HINSTANCE)GetWindowLong (hWnd, GWL_HINSTANCE), 
						MAKEINTRESOURCE(IDD_DLG_INPUTDATA), 
						hWnd, InputDlgProc)==IDOK)
				{
					// ���Ի����е��������ӵ���ǰ�ı༭����
					char szBuffer[2048];
					GetWindowText(hWndEdit, szBuffer, 2048);
					lstrcat (szBuffer, "\r\n");
					lstrcat (szBuffer, g_EditInput);
					SetWindowText(hWndEdit, szBuffer);
				}
				return 0;

			case IDM_HELP_ABOUT:
		        MessageBox (hWnd, TEXT ("�˵���ʾ���򣺴������˵����ļ����ı��༭��"),
	                        TEXT ("���ڲ˵���ʾ����"), MB_OK | MB_ICONINFORMATION);
				return 0;
			}
		}
		return 0;

	case WM_DESTROY: 
		PostQuitMessage (0);
		return 0;
	}

	return DefWindowProc (hWnd, message, wParam, lParam);

} //���� MainWndProc ����

