/*******************************************************************
����CustDlg
�ļ���CustDlg.c
���ܣ���ͨ�Ի�����ʾ���򣺵����Ի���ѡ���µ���ɫ�ı�
********************************************************************/
#include <windows.h>
#include <windowsx.h>
#include "resource.h"

BOOL InitWindow (HINSTANCE hInstance, int nCmdShow);
LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK ColorDlgProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

static int iCurrentColor  = IDC_BLACK;

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow)
{
	MSG msg;

	if (!InitWindow (hInstance, iCmdShow))
	return FALSE;

	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage (&msg);
		DispatchMessage (&msg);
	}

	return msg.wParam;
}

static BOOL InitWindow (HINSTANCE hInstance, int iCmdShow)
{
	static TCHAR szAppName[] = TEXT ("CustDlg");
	HWND hwnd;   
	WNDCLASS wc; 

	wc.style = CS_VREDRAW | CS_HREDRAW;
	wc.lpfnWndProc = WinProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon (hInstance, IDI_APPLICATION);
	wc.hCursor = LoadCursor (NULL, IDC_ARROW);
	wc.hbrBackground = GetStockObject (WHITE_BRUSH);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = szAppName;

	if (!RegisterClass (&wc))
	{
		MessageBox (NULL, TEXT ("ע�ᴰ����ʧ�ܣ�"), szAppName,
                    MB_ICONERROR);
		return 0;
	}

	hwnd = CreateWindow (szAppName, 
	                    TEXT ("��ͨ�Ի�����ʾ����"),
                     	WS_OVERLAPPEDWINDOW,
                        CW_USEDEFAULT, CW_USEDEFAULT, 
                        CW_USEDEFAULT, CW_USEDEFAULT,
                        NULL, NULL, hInstance, NULL); 

	if( !hwnd ) return FALSE;

	ShowWindow( hwnd, iCmdShow );
	UpdateWindow( hwnd );
	return TRUE;
}

LRESULT CALLBACK WinProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static COLORREF     crCustomColors[7] ={RGB(255, 0, 0), RGB(0, 255, 0),
		                                    RGB(0, 0, 255), RGB(255, 255, 0),
											RGB(255, 0, 255), RGB(0, 255, 255),
											RGB(0, 0, 0)};
	static HINSTANCE    hInstance;
	HDC                 hdc;
	PAINTSTRUCT         ps;
	RECT                rect;

	switch (message)
	{
		case WM_CREATE:
            hInstance = ((LPCREATESTRUCT) lParam)->hInstance ;
			return 0;

		case WM_RBUTTONUP:
			//�򿪡���ɫ��ͨ�öԻ���ѡ����ɫ���ӵ��Զ�����ɫ��
            if (DialogBox (hInstance, TEXT ("ColorDlg"), hWnd, ColorDlgProc))
                InvalidateRect (hWnd, NULL, TRUE);
			return 0;

		case WM_PAINT: 
			hdc = BeginPaint (hWnd, &ps); 
			GetClientRect (hWnd, &rect);

			SetTextColor (hdc, crCustomColors[iCurrentColor-IDC_RED]);
			
			DrawText (hdc, TEXT ("��ӭʹ�á�Windows �������̻�����"),
				      -1, &rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
			
			EndPaint (hWnd, &ps);
			return 0;

		case WM_DESTROY: 
			PostQuitMessage (0);
			return 0;
	}

	return DefWindowProc (hWnd, message, wParam, lParam);

} //���� WinProc ����


BOOL CALLBACK ColorDlgProc (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    static int  iColor, iFigure;
     
    switch (message)
    {
    case WM_INITDIALOG:
        iColor  = iCurrentColor;
        CheckRadioButton (hDlg, IDC_RED, IDC_BLACK, iColor);
        SetFocus (GetDlgItem (hDlg, iColor));
        return FALSE;
          
    case WM_COMMAND:
        switch (LOWORD (wParam))
        {
        case IDOK:
            iCurrentColor  = iColor;
            EndDialog (hDlg, TRUE);
            return TRUE;
             
        case IDCANCEL:
            EndDialog (hDlg, FALSE);
            return TRUE;
             
        case IDC_RED:
        case IDC_GREEN:
        case IDC_BLUE:
        case IDC_YELLOW:
        case IDC_MAGENTA:
        case IDC_CYAN:
        case IDC_BLACK:
            iColor = LOWORD (wParam);
            CheckRadioButton (hDlg, IDC_RED, IDC_BLACK, LOWORD (wParam));
            return TRUE;
        }
        break;
          
    //case WM_PAINT:
       //return 0;
    }
    return FALSE;

}//���� ColorDlgProc

