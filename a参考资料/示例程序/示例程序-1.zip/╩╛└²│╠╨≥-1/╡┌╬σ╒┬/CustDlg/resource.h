
//#define CustDlg                         101
#define IDC_RED                         1000
#define IDC_GREEN                       1001
#define IDC_BLUE                        1002
#define IDC_YELLOW                      1003
#define IDC_MAGENTA                     1004
#define IDC_CYAN                        1005
#define IDC_BLACK                       1006
